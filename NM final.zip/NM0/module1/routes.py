from flask import Blueprint, render_template, request
from .utils import get_jobs, search_jobs

module1 = Blueprint('module1', __name__)

@module1.route('/module1', methods=['GET', 'POST'])
def labour_resource_planner():
    if request.method == 'POST':
        location = request.form.get('location')
        date = request.form.get('date')
        stipend = request.form.get('stipend')
        result = search_jobs(location, date, stipend)
        return render_template('module1/module1.html', result=result)
    else:
        result = get_jobs()
        return render_template('module1/module1.html', result=result)
