import csv
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///jobs.db'  # Use your database URI
db = SQLAlchemy(app)


class Job(db.Model):
    job_id = db.Column(db.Integer, primary_key=True)
    company_name = db.Column(db.String(100), nullable=False)
    contact_email = db.Column(db.String(100), nullable=False)
    contact_phone = db.Column(db.String(15), nullable=False)
    stipend_per_hour = db.Column(db.Float, nullable=False)
    job_date = db.Column(db.String(10), nullable=False)
    job_time = db.Column(db.String(5), nullable=False)
    location = db.Column(db.String(100), nullable=False)
    job_duration = db.Column(db.Integer, nullable=False)


def populate_jobs():
    with open("C:\\Users\\Sreenidhi\\Downloads\\Nmm\\labour_resource_planner.csv", mode='r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            job = Job(
                job_id=int(row['job_id']),
                company_name=row['company_name'],
                contact_email=row['contact_email'],
                contact_phone=row['contact_phone'],
                stipend_per_hour=float(row['stipend_per_hour']),
                job_date=row['job_date'],
                job_time=row['job_time'],
                location=row['location'],
                job_duration=int(row['job_duration'])
            )
            db.session.add(job)
        db.session.commit()


if __name__ == '__main__':
    with app.app_context():  # Ensure the app context is available
        db.create_all()  # Create tables if they don't exist
        populate_jobs()  # Populate the database
