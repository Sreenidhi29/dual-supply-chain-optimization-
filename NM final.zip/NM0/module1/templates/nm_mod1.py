
from flask import Flask, jsonify, request, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///jobs.db'  # Use SQLite for simplicity
db = SQLAlchemy(app)

class Job(db.Model):
    job_id = db.Column(db.Integer, primary_key=True)
    company_name = db.Column(db.String(100), nullable=False)
    contact_email = db.Column(db.String(100), nullable=False)
    contact_phone = db.Column(db.String(15), nullable=False)
    stipend_per_hour = db.Column(db.Float, nullable=False)
    job_date = db.Column(db.String(10), nullable=False)
    job_time = db.Column(db.String(5), nullable=False)
    location = db.Column(db.String(100), nullable=False)
    job_duration = db.Column(db.Integer, nullable=False)

@app.route('/get_jobs', methods=['GET'])
def get_jobs():
    jobs = Job.query.all()
    return jsonify([{
        'job_id': job.job_id,
        'company_name': job.company_name,
        'contact_email': job.contact_email,
        'contact_phone': job.contact_phone,
        'stipend_per_hour': job.stipend_per_hour,
        'job_date': job.job_date,
        'job_time': job.job_time,
        'location': job.location,
        'job_duration': job.job_duration
    } for job in jobs])

@app.route('/search_jobs', methods=['GET'])
def search_jobs():
    location = request.args.get('location')
    date = request.args.get('date')
    stipend = request.args.get('stipend')
    query = Job.query
    if location:
        query = query.filter(Job.location == location)
    if date:
        query = query.filter(Job.job_date == date)
    if stipend:
        query = query.filter(Job.stipend_per_hour <= float(stipend))
    jobs = query.all()
    return jsonify([{
        'job_id': job.job_id,
        'company_name': job.company_name,
        'contact_email': job.contact_email,
        'contact_phone': job.contact_phone,
        'stipend_per_hour': job.stipend_per_hour,
        'job_date': job.job_date,
        'job_time': job.job_time,
        'location': job.location,
        'job_duration': job.job_duration
    } for job in jobs])

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    with app.app_context():  # Create application context
        db.create_all()  # Create database tables
    app.run(debug=True)

from flask import Blueprint, render_template, request

module1_bp = Blueprint('module1', __name__, template_folder='templates')

@module1_bp.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Handle form submission and processing
        # Example: process data and return results
        result = "Processed data from Module 1"
        return render_template('module1.html', result=result)
    return render_template('module1.html')
