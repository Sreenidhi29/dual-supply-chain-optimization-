from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')  # Serve the main HTML page

# Import and register your modules here
from module1 import module1
from module2 import module2
from module3 import module3
from module4 import module4

app.register_blueprint(module1)
app.register_blueprint(module2)
app.register_blueprint(module3)
app.register_blueprint(module4)

if __name__ == '__main__':
    app.run(debug=True)
