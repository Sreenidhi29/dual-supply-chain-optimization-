import pandas as pd

# Load the dataset once when the module is imported
data = pd.read_csv("C:\\Users\\Sreenidhi\\Downloads\\company_emissions.csv")


def get_company_info(company_id):
    # Fetch company information based on the company ID
    company_data = data[data['company_id'] == company_id]

    if company_data.empty:
        return None  # Company ID not found

    company_info = company_data.iloc[0]
    return {
        'company_id': int(company_info['company_id']),
        'company_name': company_info['company_name'],
        'transport_mode': company_info['transport_mode'],
        'monthly_emission_kgCO2': float(company_info['monthly_emission_kgCO2']),
        'emission_percentage': float(company_info['emission_percentage'])
    }
