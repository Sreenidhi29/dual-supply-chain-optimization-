from flask import Flask, render_template, request, jsonify
import pandas as pd

app = Flask(__name__)

# Load the dataset
data = pd.read_csv("C:\\Users\\Sreenidhi\\Downloads\\company_emissions.csv")
print(data.head())


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/get_company_info/<int:company_id>', methods=['GET'])
def get_company_info(company_id):
    print(f"Received request for Company ID: {company_id}")  # Debugging line
    company_data = data[data['company_id'] == company_id]
    print(company_data)  # Print the company data found

    if company_data.empty:
        print("Company ID not found")  # Debugging line
        return jsonify({'error': 'Company ID not found'}), 404

    company_info = company_data.iloc[0]

    # Convert values to native Python types
    return jsonify({
        'company_id': int(company_info['company_id']),
        'company_name': company_info['company_name'],
        'transport_mode': company_info['transport_mode'],
        'monthly_emission_kgCO2': float(company_info['monthly_emission_kgCO2']),
        'emission_percentage': float(company_info['emission_percentage'])
    })

if __name__ == '__main__':
    app.run(debug=True)


