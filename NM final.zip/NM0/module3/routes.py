from flask import Blueprint, render_template, request, jsonify
from .utils import get_company_info  # Assuming you have a function to get company info

module3 = Blueprint('module3', __name__)


@module3.route('/module3', methods=['GET'])
def carbon_emission_dashboard():
    return render_template('module3/module3.html')


@module3.route('/get_company_info/<int:company_id>', methods=['GET'])
def get_company_info_route(company_id):
    company_info = get_company_info(company_id)  # Implement this function
    return jsonify(company_info)
