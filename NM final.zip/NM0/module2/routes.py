from flask import Blueprint, render_template, request
from .utils import optimize_route  # Assuming you have a function to optimize routes

module2 = Blueprint('module2', __name__)


@module2.route('/module2', methods=['GET', 'POST'])
def green_logistics():
    if request.method == 'POST':
        start = request.form.get('start')
        destination = request.form.get('destination')
        transport_mode = request.form.get('mode')
        result = optimize_route(start, destination, transport_mode)  # Implement this function
        return render_template('module2/module2.html', result=result)
    return render_template('module2/module2.html')
