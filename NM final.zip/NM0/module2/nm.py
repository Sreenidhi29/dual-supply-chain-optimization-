from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

# Carbon footprint factors (kg CO2 per km)
CAR_EMISSION_FACTOR = 0.192  # Example average car emissions per km
PUBLIC_TRANSIT_FACTOR = 0.105  # Estimate for public transit
CYCLING_FACTOR = 0  # No emissions for cycling


def geocode_location(location):
    """Use Nominatim to geocode a location string to lat, lon."""
    url = "https://nominatim.openstreetmap.org/search"
    params = {
        'q': location,
        'format': 'json',
        'limit': 1
    }
    response = requests.get(url, params=params, headers={'User-Agent': 'GreenLogisticsApp/1.0'})
    data = response.json()
    if not data:
        return None
    return float(data[0]['lat']), float(data[0]['lon']), data[0]['display_name']


def get_route(start_coord, end_coord):
    """Use OSRM API to get the optimized route between two coordinates (lon, lat)."""
    base_url = "http://router.project-osrm.org/route/v1/driving/"
    coords = f"{start_coord[1]},{start_coord[0]};{end_coord[1]},{end_coord[0]}"
    url = base_url + coords
    params = {
        'overview': 'full',
        'geometries': 'geojson',
        'steps': 'true'
    }
    response = requests.get(url, params=params)
    data = response.json()
    if data['code'] != 'Ok':
        return None
    route = data['routes'][0]
    distance_m = route['distance']
    duration_s = route['duration']
    steps = []
    for leg in route['legs']:
        for step in leg['steps']:
            instruction = step['maneuver']['instruction'] if 'instruction' in step['maneuver'] else step['name']
            steps.append(instruction)
    return {
        'distance_km': distance_m / 1000.0,
        'duration_min': duration_s / 60.0,
        'steps': steps,
        'geometry': route['geometry']
    }


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/optimize_route', methods=['POST'])
def optimize_route_endpoint():
    start = request.form.get('start')
    destination = request.form.get('destination')
    transport_mode = request.form.get('mode', 'driving')  # Allow user to choose mode (driving/public_transport/cycling)

    if not start or not destination:
        return jsonify({'error': 'Please provide both start and destination locations'}), 400

    # Geocode start and destination
    start_geo = geocode_location(start)
    destination_geo = geocode_location(destination)
    if start_geo is None:
        return jsonify({'error': f"Could not geocode start location: {start}"}), 400
    if destination_geo is None:
        return jsonify({'error': f"Could not geocode destination location: {destination}"}), 400

    start_coord = (start_geo[0], start_geo[1])
    dest_coord = (destination_geo[0], destination_geo[1])

    # Depending on transport mode, call relevant routing
    # OSRM supports driving, walking, cycling.
    # For public transit, no free OSRM supported publicly. We simulate or fallback to walking.
    if transport_mode == 'driving':
        profile = 'driving'
    elif transport_mode == 'cycling':
        profile = 'cycling'
    elif transport_mode == 'walking':
        profile = 'walking'
    else:
        profile = 'driving'

    # Build OSRM URL with profile
    base_url = f"http://router.project-osrm.org/route/v1/{profile}/"
    coords = f"{start_coord[1]},{start_coord[0]};{dest_coord[1]},{dest_coord[0]}"
    params = {
        'overview': 'full',
        'geometries': 'geojson',
        'steps': 'true'
    }
    response = requests.get(base_url + coords, params=params)
    data = response.json()
    if data['code'] != 'Ok':
        return jsonify({'error': 'Route calculation failed, try another location or mode.'}), 500

    route = data['routes'][0]
    distance_km = route['distance'] / 1000.0
    duration_min = route['duration'] / 60.0
    steps = []
    for leg in route['legs']:
        for step in leg['steps']:
            instr = step['maneuver'].get('instruction', '')
            name = step.get('name', '')
            step_desc = f"{instr} onto {name}" if name else instr
            steps.append(step_desc)

    # Calculate estimated carbon emissions and savings
    if transport_mode == 'driving':
        carbon_footprint = distance_km * CAR_EMISSION_FACTOR
        carbon_savings = 0.0
    elif transport_mode == 'cycling':
        carbon_footprint = distance_km * CYCLING_FACTOR
        # Assume saving compared to car
        carbon_savings = distance_km * CAR_EMISSION_FACTOR
    elif transport_mode == 'walking':
        carbon_footprint = 0.0
        carbon_savings = distance_km * CAR_EMISSION_FACTOR
    else:
        # Default fallback
        carbon_footprint = distance_km * CAR_EMISSION_FACTOR
        carbon_savings = 0.0

    return jsonify({
        'start_display': start_geo[2],
        'destination_display': destination_geo[2],
        'distance_km': round(distance_km, 2),
        'duration_min': round(duration_min, 1),
        'steps': steps,
        'carbon_footprint_kg': round(carbon_footprint, 3),
        'carbon_savings_kg': round(carbon_savings, 3),
        'travel_mode': transport_mode
    })


if __name__ == '__main__':
    app.run(debug=True)

