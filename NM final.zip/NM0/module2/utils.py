import requests

def optimize_route(start, destination, transport_mode):
    # Example function to optimize the route using an external API
    # Replace with your actual API logic
    # Here we simulate a response for demonstration purposes
    response = {
        'start_display': start,
        'destination_display': destination,
        'distance_km': 10.5,  # Example distance
        'duration_min': 15,    # Example duration
        'carbon_footprint_kg': 2.5,  # Example carbon footprint
        'carbon_savings_kg': 1.0,     # Example carbon savings
        'steps': ['Step 1: Go straight', 'Step 2: Turn left at the traffic light']
    }
    return response
