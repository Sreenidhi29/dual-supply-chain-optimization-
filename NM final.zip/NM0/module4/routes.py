from flask import Blueprint, render_template, request
from .utils import analyze_trade_off  # Assuming you have a function to analyze trade-offs

module4 = Blueprint('module4', __name__)


@module4.route('/module4', methods=['GET', 'POST'])
def cost_carbon_trade_off_analyzer():
    if request.method == 'POST':
        data = request.form  # Get data from the form
        result = analyze_trade_off(data)  # Implement this function
        return render_template('module4/module4.html', result=result)
    return render_template('module4/module4.html')
