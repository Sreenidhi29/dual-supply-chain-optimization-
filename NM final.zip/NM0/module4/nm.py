from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for local frontend testing

# Predefined responses for keywords
RESPONSE_MAP = {
    "jobs": "Visit our jobs page to explore current openings: https://www.example.com/jobs",
    "emissions": "Learn about our emissions policies here: https://www.example.com/emissions",
    "route": "Check route information and schedules at: https://www.example.com/routes",
    "contact": "You can reach support at support@example.com or call 123-456-7890.",
    "support": "You can reach support at support@example.com or call 123-456-7890.",
}

@app.route('/chatbot_response', methods=['POST'])
def chatbot_response():
    data = request.get_json()
    user_message = data.get("message", "").strip().lower()

    # Determine which keyword the message contains
    for keyword in RESPONSE_MAP:
        if keyword in user_message:
            response = RESPONSE_MAP[keyword]
            break
    else:
        response = "Sorry, I didn't understand that. Please ask about jobs, emissions, routes, or contact support."

    return jsonify({"response": response})

@app.route('/')
def index():
    html = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <title>Chatbot Widget</title>
      <style>
        body {
          margin: 0;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          height: 100vh;
          overflow: hidden;
          background: #f9f9f9;
        }
        #chatbot-container {
          position: fixed;
          bottom: 20px;
          right: 20px;
          width: 320px;
          max-height: 600px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
          background: #fff;
          border-radius: 10px;
          display: flex;
          flex-direction: column;
          overflow: hidden;
        }
        #chatbot-header {
          background: #007bff;
          color: white;
          padding: 12px 16px;
          font-weight: bold;
          font-size: 1.2em;
          user-select: none;
        }
        #chatbot-messages {
          flex: 1;
          padding: 12px 16px;
          display: flex;
          flex-direction: column;
          overflow-y: auto;
          scrollbar-width: thin;
          scrollbar-color: #007bff transparent;
        }
        #chatbot-messages::-webkit-scrollbar {
          width: 6px;
        }
        #chatbot-messages::-webkit-scrollbar-thumb {
          background-color: #007bff;
          border-radius: 3px;
        }
        .message {
          margin-bottom: 12px;
          line-height: 1.3;
          font-size: 0.9em;
          max-width: 80%;
          word-wrap: break-word;
        }
        .message.user {
          align-self: flex-end;
          background-color: #e0f0ff;
          padding: 8px 12px;
          border-radius: 15px 15px 0 15px;
          color: #024a8a;
        }
        .message.bot {
          align-self: flex-start;
          background-color: #f1f1f1;
          padding: 8px 12px;
          border-radius: 15px 15px 15px 0;
          color: #333;
        }
        #chatbot-input-area {
          display: flex;
          border-top: 1px solid #ddd;
          padding: 10px 12px;
          background: #fafafa;
        }
        #chatbot-input {
          flex-grow: 1;
          border: 1px solid #ccc;
          border-radius: 25px;
          padding: 8px 16px;
          font-size: 1em;
          outline: none;
          transition: border-color 0.3s ease;
        }
        #chatbot-input:focus {
          border-color: #007bff;
        }
        #chatbot-submit {
          background: #007bff;
          border: none;
          color: white;
          margin-left: 10px;
          padding: 0 16px;
          border-radius: 25px;
          cursor: pointer;
          font-weight: bold;
          transition: background-color 0.3s ease;
          user-select: none;
        }
        #chatbot-submit:hover:not(:disabled) {
          background: #0056b3;
        }
        #chatbot-submit:disabled {
          background: #8ab4f8;
          cursor: not-allowed;
        }
        @media (max-width: 360px) {
          #chatbot-container {
            width: 90vw;
            right: 5vw;
            bottom: 15px;
          }
        }
      </style>
    </head>
    <body>
      <div id="chatbot-container" role="region" aria-label="Chatbot">
        <div id="chatbot-header">Support Chatbot</div>
        <div id="chatbot-messages" aria-live="polite" aria-atomic="false"></div>
        <form id="chatbot-form" autocomplete="off">
          <div id="chatbot-input-area">
            <input type="text" id="chatbot-input" placeholder="Ask me about jobs, emissions, routes, or support..." aria-label="Chat input" required />
            <button type="submit" id="chatbot-submit" aria-label="Send message">Send</button>
          </div>
        </form>
      </div>
      <script>
        const form = document.getElementById('chatbot-form');
        const input = document.getElementById('chatbot-input');
        const messagesContainer = document.getElementById('chatbot-messages');
        const submitButton = document.getElementById('chatbot-submit');

        function appendMessage(text, sender) {
          const messageDiv = document.createElement('div');
          messageDiv.classList.add('message', sender);
          messageDiv.textContent = text;
          messagesContainer.appendChild(messageDiv);
          messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }

        form.addEventListener('submit', async (e) => {
          e.preventDefault();
          const userMessage = input.value.trim();
          if (!userMessage) return;

          appendMessage(userMessage, 'user');
          input.value = '';
          submitButton.disabled = true;

          try {
            const response = await fetch('/chatbot_response', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ message: userMessage })
            });

            if (!response.ok) {
              throw new Error('Network response was not ok');
            }

            const data = await response.json();
            appendMessage(data.response, 'bot');
          } catch (error) {
            appendMessage('Sorry, there was an error processing your request.', 'bot');
            console.error('Error:', error);
          } finally {
            submitButton.disabled = false;
            input.focus();
          }
        });
      </script>
    </body>
    </html>
    """
    return render_template_string(html)

if __name__ == '__main__':
    app.run(debug=True)

